<?php
// Chemin vers la base de données SQLite
$dbPath = 'cluedo.db';

// Création d'une nouvelle connexion à la base de données SQLite
try {
    $pdo = new PDO("sqlite:" . $dbPath);
    // Définir les options pour une gestion d'erreurs propre
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Exécuter la requête pour récupérer les noms des personnages
    $query = "SELECT nom_personnage FROM personnages";
    $stmt = $pdo->prepare($query);
    $stmt->execute();
    
    // Récupérer les résultats sous forme de tableau associatif
    $personnages = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Vérifier s'il y a des résultats
    if ($personnages) {
        // Afficher les noms des personnages
        foreach ($personnages as $personnage) {
            echo $personnage['nom_personnage'] . "<br>";
        }
    } else {
        echo "Aucun personnage trouvé dans la base de données.";
    }

} catch (PDOException $e) {
    // En cas d'erreur, afficher un message
    echo "Erreur de connexion à la base de données : " . $e->getMessage();
}
?>

